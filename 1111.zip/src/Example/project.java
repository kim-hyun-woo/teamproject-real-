package Example;

public class project {
public project() {
  System.out.println("hello world");

}
}

